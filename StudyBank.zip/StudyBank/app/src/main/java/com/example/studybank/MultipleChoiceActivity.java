package com.example.studybank;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MultipleChoiceActivity extends AppCompatActivity {
    RadioButton rButton;
    EditText questionText, optionText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multiple_choice);
    }

    public void onSubmit(View view) {
        Toast.makeText(MultipleChoiceActivity.this, "This question has been submitted", Toast.LENGTH_LONG).show();
        rButton = findViewById(R.id.option1);
        optionText = findViewById(R.id.optionText1);
        rButton.setChecked(false);
        optionText.setText(null);
        rButton = findViewById(R.id.option2);
        optionText = findViewById(R.id.optionText2);
        rButton.setChecked(false);
        optionText.setText(null);
        rButton = findViewById(R.id.option3);
        optionText = findViewById(R.id.optionText3);
        rButton.setChecked(false);
        optionText.setText(null);
        rButton = findViewById(R.id.option4);
        optionText = findViewById(R.id.optionText4);
        rButton.setChecked(false);
        optionText.setText(null);

        questionText=findViewById(R.id.questionEditText);
        questionText.setText(null);
    }

    public void onBack(View view) {
        AlertDialog.Builder alert = new AlertDialog.Builder(MultipleChoiceActivity.this);
        alert.setTitle("Do you want to leave this activity?");
        alert.setPositiveButton(R.string.okButton, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(MultipleChoiceActivity.this, CreateActivity.class);
                startActivity(intent);
            }
        });
        alert.setNegativeButton(R.string.noButton, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        AlertDialog dialog = alert.create();
        dialog.show();
    }

    public void onCreateTF(View view) {
        Intent intent = new Intent(MultipleChoiceActivity.this, TrueFalseActivity.class);
        startActivity(intent);
    }
}