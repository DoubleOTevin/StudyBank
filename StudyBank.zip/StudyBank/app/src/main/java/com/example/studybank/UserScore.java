package com.example.studybank;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UserScore extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_score);
    }
}