package com.example.studybank;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.*;

public class QuizActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        Random random = new Random();

        // Sample data
        final int sample_score = 100;

        // Initialize progress bar
        final ProgressBar progress = (ProgressBar) findViewById(R.id.progress);
        progress.setMax(1);

        // Initialize percent textview
        final TextView percent = (TextView) findViewById(R.id.percent);

        // Initialize question textview
        final TextView question = (TextView) findViewById(R.id.questionView);

        // Initialize buttons list
        Button button1 = (Button) findViewById(R.id.button1);
        Button button2 = (Button) findViewById(R.id.button2);
        Button button3 = (Button) findViewById(R.id.button3);
        Button button4 = (Button) findViewById(R.id.button4);

        ArrayList<Button> buttonsList = new ArrayList<Button>();
        buttonsList.add(button1);
        buttonsList.add(button2);
        buttonsList.add(button3);
        buttonsList.add(button4);

        // Display question
        question.setText(R.string.sample_question);

        // Set correct button
        Button correctButton;
        int correct = random.nextInt(4);
        correctButton = buttonsList.get(correct);

        correctButton.setText(R.string.sample_answer_correct);

        correctButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Toast correctToast = Toast.makeText(QuizActivity.this, "Correct!", Toast.LENGTH_SHORT);
                correctToast.show();
                finish();
            }
        });

        // Set incorrect buttons
        Button incorrectButton;

        for(Button button : buttonsList){
            if (button != correctButton){
                button.setText(R.string.sample_answer_incorrect);

                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast incorrectToast = Toast.makeText(QuizActivity.this, "Incorrect...!", Toast.LENGTH_SHORT);
                        incorrectToast.show();
                    }
                });
            }

        }



    }
}




